/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************
//
// GPIO18 - GPIO Settings
//
#define LED1_GPIO_GPIO_PIN_CONFIG GPIO_18_GPIO18
//
// GPIO17 - GPIO Settings
//
#define LED2_GPIO_GPIO_PIN_CONFIG GPIO_17_GPIO17
//
// GPIO16 - GPIO Settings
//
#define LED3_GPIO_GPIO_PIN_CONFIG GPIO_16_GPIO16
//
// GPIO19 - GPIO Settings
//
#define LED4_GPIO_GPIO_PIN_CONFIG GPIO_19_GPIO19
//
// GPIO2 - GPIO Settings
//
#define inst_GPIO2_GPIO_PIN_CONFIG GPIO_2_GPIO2
//
// GPIO3 - GPIO Settings
//
#define inst_GPIO3_GPIO_PIN_CONFIG GPIO_3_GPIO3
//
// GPIO4 - GPIO Settings
//
#define inst_GPIO4_GPIO_PIN_CONFIG GPIO_4_GPIO4
//
// GPIO5 - GPIO Settings
//
#define inst_GPIO5_GPIO_PIN_CONFIG GPIO_5_GPIO5
//
// GPIO6 - GPIO Settings
//
#define inst_GPIO6_GPIO_PIN_CONFIG GPIO_6_GPIO6
//
// GPIO7 - GPIO Settings
//
#define inst_GPIO7_GPIO_PIN_CONFIG GPIO_7_GPIO7
//
// GPIO8 - GPIO Settings
//
#define inst_GPIO8_GPIO_PIN_CONFIG GPIO_8_GPIO8
//
// GPIO9 - GPIO Settings
//
#define inst_GPIO9_GPIO_PIN_CONFIG GPIO_9_GPIO9
//
// GPIO11 - GPIO Settings
//
#define inst_GPIO11_GPIO_PIN_CONFIG GPIO_11_GPIO11
//
// GPIO12 - GPIO Settings
//
#define inst_GPIO12_GPIO_PIN_CONFIG GPIO_12_GPIO12
//
// GPIO13 - GPIO Settings
//
#define inst_GPIO13_GPIO_PIN_CONFIG GPIO_13_GPIO13
//
// GPIO14 - GPIO Settings
//
#define inst_GPIO14_GPIO_PIN_CONFIG GPIO_14_GPIO14
//
// GPIO15 - GPIO Settings
//
#define inst_GPIO15_GPIO_PIN_CONFIG GPIO_15_GPIO15
//
// GPIO10 - GPIO Settings
//
#define inst_GPIO10_GPIO_PIN_CONFIG GPIO_10_GPIO10
//
// GPIO20 - GPIO Settings
//
#define inst_GPIO20_GPIO_PIN_CONFIG GPIO_20_GPIO20
//
// GPIO21 - GPIO Settings
//
#define inst_GPIO21_GPIO_PIN_CONFIG GPIO_21_GPIO21
//
// GPIO22 - GPIO Settings
//
#define inst_GPIO22_GPIO_PIN_CONFIG GPIO_22_GPIO22
//
// GPIO23 - GPIO Settings
//
#define inst_GPIO23_GPIO_PIN_CONFIG GPIO_23_GPIO23
//
// GPIO24 - GPIO Settings
//
#define inst_GPIO24_GPIO_PIN_CONFIG GPIO_24_GPIO24
//
// GPIO25 - GPIO Settings
//
#define inst_GPIO25_GPIO_PIN_CONFIG GPIO_25_GPIO25
//
// GPIO26 - GPIO Settings
//
#define inst_GPIO26_GPIO_PIN_CONFIG GPIO_26_GPIO26
//
// GPIO27 - GPIO Settings
//
#define inst_GPIO27_GPIO_PIN_CONFIG GPIO_27_GPIO27
//
// GPIO30 - GPIO Settings
//
#define inst_GPIO30_GPIO_PIN_CONFIG GPIO_30_GPIO30
//
// GPIO32 - GPIO Settings
//
#define inst_GPIO32_GPIO_PIN_CONFIG GPIO_32_GPIO32
//
// GPIO33 - GPIO Settings
//
#define inst_GPIO33_GPIO_PIN_CONFIG GPIO_33_GPIO33
//
// GPIO36 - GPIO Settings
//
#define inst_GPIO36_GPIO_PIN_CONFIG GPIO_36_GPIO36
//
// GPIO43 - GPIO Settings
//
#define inst_GPIO43_GPIO_PIN_CONFIG GPIO_43_GPIO43
//
// GPIO53 - GPIO Settings
//
#define inst_GPIO53_GPIO_PIN_CONFIG GPIO_53_GPIO53
//
// GPIO54 - GPIO Settings
//
#define inst_GPIO54_GPIO_PIN_CONFIG GPIO_54_GPIO54
//
// GPIO55 - GPIO Settings
//
#define inst_GPIO55_GPIO_PIN_CONFIG GPIO_55_GPIO55
//
// GPIO56 - GPIO Settings
//
#define inst_GPIO56_GPIO_PIN_CONFIG GPIO_56_GPIO56
//
// GPIO57 - GPIO Settings
//
#define inst_GPIO57_GPIO_PIN_CONFIG GPIO_57_GPIO57
//
// GPIO62 - GPIO Settings
//
#define inst_GPIO62_GPIO_PIN_CONFIG GPIO_62_GPIO62
//
// GPIO63 - GPIO Settings
//
#define inst_GPIO63_GPIO_PIN_CONFIG GPIO_63_GPIO63
//
// GPIO64 - GPIO Settings
//
#define inst_GPIO64_GPIO_PIN_CONFIG GPIO_64_GPIO64
//
// GPIO65 - GPIO Settings
//
#define inst_GPIO65_GPIO_PIN_CONFIG GPIO_65_GPIO65
//
// GPIO66 - GPIO Settings
//
#define inst_GPIO66_GPIO_PIN_CONFIG GPIO_66_GPIO66
//
// GPIO84 - GPIO Settings
//
#define inst_GPIO84_GPIO_PIN_CONFIG GPIO_84_GPIO84
//
// GPIO93 - GPIO Settings
//
#define inst_GPIO93_GPIO_PIN_CONFIG GPIO_93_GPIO93
//
// GPIO94 - GPIO Settings
//
#define inst_GPIO94_GPIO_PIN_CONFIG GPIO_94_GPIO94
//
// GPIO95 - GPIO Settings
//
#define inst_GPIO95_GPIO_PIN_CONFIG GPIO_95_GPIO95
//
// GPIO96 - GPIO Settings
//
#define inst_GPIO96_GPIO_PIN_CONFIG GPIO_96_GPIO96
//
// GPIO97 - GPIO Settings
//
#define inst_GPIO97_GPIO_PIN_CONFIG GPIO_97_GPIO97
//
// GPIO98 - GPIO Settings
//
#define inst_GPIO98_GPIO_PIN_CONFIG GPIO_98_GPIO98
//
// GPIO99 - GPIO Settings
//
#define inst_GPIO99_GPIO_PIN_CONFIG GPIO_99_GPIO99
//
// GPIO100 - GPIO Settings
//
#define inst_GPIO100_GPIO_PIN_CONFIG GPIO_100_GPIO100
//
// GPIO101 - GPIO Settings
//
#define inst_GPIO101_GPIO_PIN_CONFIG GPIO_101_GPIO101
//
// GPIO102 - GPIO Settings
//
#define inst_GPIO102_GPIO_PIN_CONFIG GPIO_102_GPIO102
//
// GPIO103 - GPIO Settings
//
#define inst_GPIO103_GPIO_PIN_CONFIG GPIO_103_GPIO103
//
// GPIO104 - GPIO Settings
//
#define inst_GPIO104_GPIO_PIN_CONFIG GPIO_104_GPIO104
//
// GPIO105 - GPIO Settings
//
#define inst_GPIO105_GPIO_PIN_CONFIG GPIO_105_GPIO105
//
// GPIO108 - GPIO Settings
//
#define inst_GPIO108_GPIO_PIN_CONFIG GPIO_108_GPIO108
//
// GPIO110 - GPIO Settings
//
#define inst_GPIO110_GPIO_PIN_CONFIG GPIO_110_GPIO110
//
// GPIO111 - GPIO Settings
//
#define inst_GPIO111_GPIO_PIN_CONFIG GPIO_111_GPIO111
//
// GPIO119 - GPIO Settings
//
#define inst_GPIO119_GPIO_PIN_CONFIG GPIO_119_GPIO119
//
// GPIO125 - GPIO Settings
//
#define inst_GPIO125_GPIO_PIN_CONFIG GPIO_125_GPIO125
//
// GPIO126 - GPIO Settings
//
#define inst_GPIO126_GPIO_PIN_CONFIG GPIO_126_GPIO126
//
// GPIO127 - GPIO Settings
//
#define inst_GPIO127_GPIO_PIN_CONFIG GPIO_127_GPIO127
//
// GPIO128 - GPIO Settings
//
#define inst_GPIO128_GPIO_PIN_CONFIG GPIO_128_GPIO128
//
// GPIO129 - GPIO Settings
//
#define inst_GPIO129_GPIO_PIN_CONFIG GPIO_129_GPIO129
//
// GPIO130 - GPIO Settings
//
#define inst_GPIO130_GPIO_PIN_CONFIG GPIO_130_GPIO130
//
// GPIO131 - GPIO Settings
//
#define inst_GPIO131_GPIO_PIN_CONFIG GPIO_131_GPIO131
//
// GPIO132 - GPIO Settings
//
#define inst_GPIO132_GPIO_PIN_CONFIG GPIO_132_GPIO132
//
// GPIO133 - GPIO Settings
//
#define inst_GPIO133_GPIO_PIN_CONFIG GPIO_133_GPIO133
//
// GPIO134 - GPIO Settings
//
#define inst_GPIO134_GPIO_PIN_CONFIG GPIO_134_GPIO134
//
// GPIO135 - GPIO Settings
//
#define inst_GPIO135_GPIO_PIN_CONFIG GPIO_135_GPIO135
//
// GPIO136 - GPIO Settings
//
#define inst_GPIO136_GPIO_PIN_CONFIG GPIO_136_GPIO136
//
// GPIO137 - GPIO Settings
//
#define inst_GPIO137_GPIO_PIN_CONFIG GPIO_137_GPIO137
//
// GPIO138 - GPIO Settings
//
#define inst_GPIO138_GPIO_PIN_CONFIG GPIO_138_GPIO138
//
// GPIO139 - GPIO Settings
//
#define inst_GPIO139_GPIO_PIN_CONFIG GPIO_139_GPIO139
//
// GPIO140 - GPIO Settings
//
#define inst_GPIO140_GPIO_PIN_CONFIG GPIO_140_GPIO140
//
// GPIO141 - GPIO Settings
//
#define inst_GPIO141_GPIO_PIN_CONFIG GPIO_141_GPIO141
//
// GPIO142 - GPIO Settings
//
#define inst_GPIO142_GPIO_PIN_CONFIG GPIO_142_GPIO142
//
// GPIO143 - GPIO Settings
//
#define inst_GPIO143_GPIO_PIN_CONFIG GPIO_143_GPIO143
//
// GPIO144 - GPIO Settings
//
#define inst_GPIO144_GPIO_PIN_CONFIG GPIO_144_GPIO144
//
// GPIO145 - GPIO Settings
//
#define inst_GPIO145_GPIO_PIN_CONFIG GPIO_145_GPIO145
//
// GPIO146 - GPIO Settings
//
#define inst_GPIO146_GPIO_PIN_CONFIG GPIO_146_GPIO146
//
// GPIO147 - GPIO Settings
//
#define inst_GPIO147_GPIO_PIN_CONFIG GPIO_147_GPIO147
//
// GPIO148 - GPIO Settings
//
#define inst_GPIO148_GPIO_PIN_CONFIG GPIO_148_GPIO148
//
// GPIO149 - GPIO Settings
//
#define inst_GPIO149_GPIO_PIN_CONFIG GPIO_149_GPIO149
//
// GPIO150 - GPIO Settings
//
#define inst_GPIO150_GPIO_PIN_CONFIG GPIO_150_GPIO150
//
// GPIO151 - GPIO Settings
//
#define inst_GPIO151_GPIO_PIN_CONFIG GPIO_151_GPIO151
//
// GPIO152 - GPIO Settings
//
#define inst_GPIO152_GPIO_PIN_CONFIG GPIO_152_GPIO152
//
// GPIO153 - GPIO Settings
//
#define inst_GPIO153_GPIO_PIN_CONFIG GPIO_153_GPIO153
//
// GPIO154 - GPIO Settings
//
#define inst_GPIO154_GPIO_PIN_CONFIG GPIO_154_GPIO154
//
// GPIO155 - GPIO Settings
//
#define inst_GPIO155_GPIO_PIN_CONFIG GPIO_155_GPIO155
//
// GPIO156 - GPIO Settings
//
#define inst_GPIO156_GPIO_PIN_CONFIG GPIO_156_GPIO156
//
// GPIO157 - GPIO Settings
//
#define inst_GPIO157_GPIO_PIN_CONFIG GPIO_157_GPIO157
//
// GPIO158 - GPIO Settings
//
#define inst_GPIO158_GPIO_PIN_CONFIG GPIO_158_GPIO158
//
// GPIO159 - GPIO Settings
//
#define inst_GPIO159_GPIO_PIN_CONFIG GPIO_159_GPIO159
//
// GPIO160 - GPIO Settings
//
#define inst_GPIO160_GPIO_PIN_CONFIG GPIO_160_GPIO160
//
// GPIO161 - GPIO Settings
//
#define inst_GPIO161_GPIO_PIN_CONFIG GPIO_161_GPIO161
//
// GPIO162 - GPIO Settings
//
#define inst_GPIO162_GPIO_PIN_CONFIG GPIO_162_GPIO162
//
// GPIO163 - GPIO Settings
//
#define inst_GPIO163_GPIO_PIN_CONFIG GPIO_163_GPIO163
//
// GPIO164 - GPIO Settings
//
#define inst_GPIO164_GPIO_PIN_CONFIG GPIO_164_GPIO164
//
// GPIO165 - GPIO Settings
//
#define inst_GPIO165_GPIO_PIN_CONFIG GPIO_165_GPIO165
//
// GPIO166 - GPIO Settings
//
#define inst_GPIO166_GPIO_PIN_CONFIG GPIO_166_GPIO166
//
// GPIO167 - GPIO Settings
//
#define inst_GPIO167_GPIO_PIN_CONFIG GPIO_167_GPIO167
//
// GPIO168 - GPIO Settings
//
#define inst_GPIO168_GPIO_PIN_CONFIG GPIO_168_GPIO168
//
// GPIO72 - GPIO Settings
//
#define inst_GPIO72_GPIO_PIN_CONFIG GPIO_72_GPIO72

//
// SCIA -> SCIA_inst Pinmux
//
//
// SCIRXDA - GPIO Settings
//
#define GPIO_PIN_SCIRXDA 28
#define SCIA_inst_SCIRX_GPIO 28
#define SCIA_inst_SCIRX_PIN_CONFIG GPIO_28_SCIRXDA
//
// SCITXDA - GPIO Settings
//
#define GPIO_PIN_SCITXDA 29
#define SCIA_inst_SCITX_GPIO 29
#define SCIA_inst_SCITX_PIN_CONFIG GPIO_29_SCITXDA

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define ADCA_inst_BASE ADCA_BASE
#define ADCA_inst_RESULT_BASE ADCARESULT_BASE
#define ADCA_inst_SOC0 ADC_SOC_NUMBER0
#define ADCA_inst_FORCE_SOC0 ADC_FORCE_SOC0
#define ADCA_inst_SAMPLE_WINDOW_SOC0 2500
#define ADCA_inst_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_SW_ONLY
#define ADCA_inst_CHANNEL_SOC0 ADC_CH_ADCIN0
#define ADCA_inst_SOC1 ADC_SOC_NUMBER1
#define ADCA_inst_FORCE_SOC1 ADC_FORCE_SOC1
#define ADCA_inst_SAMPLE_WINDOW_SOC1 2500
#define ADCA_inst_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_SW_ONLY
#define ADCA_inst_CHANNEL_SOC1 ADC_CH_ADCIN1
#define ADCA_inst_SOC2 ADC_SOC_NUMBER2
#define ADCA_inst_FORCE_SOC2 ADC_FORCE_SOC2
#define ADCA_inst_SAMPLE_WINDOW_SOC2 2500
#define ADCA_inst_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_SW_ONLY
#define ADCA_inst_CHANNEL_SOC2 ADC_CH_ADCIN2
#define ADCA_inst_SOC3 ADC_SOC_NUMBER3
#define ADCA_inst_FORCE_SOC3 ADC_FORCE_SOC3
#define ADCA_inst_SAMPLE_WINDOW_SOC3 2500
#define ADCA_inst_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_SW_ONLY
#define ADCA_inst_CHANNEL_SOC3 ADC_CH_ADCIN3
#define ADCA_inst_SOC4 ADC_SOC_NUMBER4
#define ADCA_inst_FORCE_SOC4 ADC_FORCE_SOC4
#define ADCA_inst_SAMPLE_WINDOW_SOC4 2500
#define ADCA_inst_TRIGGER_SOURCE_SOC4 ADC_TRIGGER_SW_ONLY
#define ADCA_inst_CHANNEL_SOC4 ADC_CH_ADCIN4
#define ADCA_inst_SOC5 ADC_SOC_NUMBER5
#define ADCA_inst_FORCE_SOC5 ADC_FORCE_SOC5
#define ADCA_inst_SAMPLE_WINDOW_SOC5 2500
#define ADCA_inst_TRIGGER_SOURCE_SOC5 ADC_TRIGGER_SW_ONLY
#define ADCA_inst_CHANNEL_SOC5 ADC_CH_ADCIN5
void ADCA_inst_init();

#define ADCB_inst_BASE ADCB_BASE
#define ADCB_inst_RESULT_BASE ADCBRESULT_BASE
#define ADCB_inst_SOC0 ADC_SOC_NUMBER0
#define ADCB_inst_FORCE_SOC0 ADC_FORCE_SOC0
#define ADCB_inst_SAMPLE_WINDOW_SOC0 2500
#define ADCB_inst_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_SW_ONLY
#define ADCB_inst_CHANNEL_SOC0 ADC_CH_ADCIN0
#define ADCB_inst_SOC1 ADC_SOC_NUMBER1
#define ADCB_inst_FORCE_SOC1 ADC_FORCE_SOC1
#define ADCB_inst_SAMPLE_WINDOW_SOC1 2500
#define ADCB_inst_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_SW_ONLY
#define ADCB_inst_CHANNEL_SOC1 ADC_CH_ADCIN1
#define ADCB_inst_SOC2 ADC_SOC_NUMBER2
#define ADCB_inst_FORCE_SOC2 ADC_FORCE_SOC2
#define ADCB_inst_SAMPLE_WINDOW_SOC2 2500
#define ADCB_inst_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_SW_ONLY
#define ADCB_inst_CHANNEL_SOC2 ADC_CH_ADCIN2
#define ADCB_inst_SOC3 ADC_SOC_NUMBER3
#define ADCB_inst_FORCE_SOC3 ADC_FORCE_SOC3
#define ADCB_inst_SAMPLE_WINDOW_SOC3 2500
#define ADCB_inst_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_SW_ONLY
#define ADCB_inst_CHANNEL_SOC3 ADC_CH_ADCIN3
#define ADCB_inst_SOC4 ADC_SOC_NUMBER4
#define ADCB_inst_FORCE_SOC4 ADC_FORCE_SOC4
#define ADCB_inst_SAMPLE_WINDOW_SOC4 2500
#define ADCB_inst_TRIGGER_SOURCE_SOC4 ADC_TRIGGER_SW_ONLY
#define ADCB_inst_CHANNEL_SOC4 ADC_CH_ADCIN4
#define ADCB_inst_SOC5 ADC_SOC_NUMBER5
#define ADCB_inst_FORCE_SOC5 ADC_FORCE_SOC5
#define ADCB_inst_SAMPLE_WINDOW_SOC5 2500
#define ADCB_inst_TRIGGER_SOURCE_SOC5 ADC_TRIGGER_SW_ONLY
#define ADCB_inst_CHANNEL_SOC5 ADC_CH_ADCIN5
void ADCB_inst_init();

#define ADCC_inst_BASE ADCC_BASE
#define ADCC_inst_RESULT_BASE ADCCRESULT_BASE
#define ADCC_inst_SOC0 ADC_SOC_NUMBER0
#define ADCC_inst_FORCE_SOC0 ADC_FORCE_SOC0
#define ADCC_inst_SAMPLE_WINDOW_SOC0 2500
#define ADCC_inst_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_SW_ONLY
#define ADCC_inst_CHANNEL_SOC0 ADC_CH_ADCIN14
#define ADCC_inst_SOC1 ADC_SOC_NUMBER1
#define ADCC_inst_FORCE_SOC1 ADC_FORCE_SOC1
#define ADCC_inst_SAMPLE_WINDOW_SOC1 2500
#define ADCC_inst_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_SW_ONLY
#define ADCC_inst_CHANNEL_SOC1 ADC_CH_ADCIN15
#define ADCC_inst_SOC2 ADC_SOC_NUMBER2
#define ADCC_inst_FORCE_SOC2 ADC_FORCE_SOC2
#define ADCC_inst_SAMPLE_WINDOW_SOC2 2500
#define ADCC_inst_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_SW_ONLY
#define ADCC_inst_CHANNEL_SOC2 ADC_CH_ADCIN2
#define ADCC_inst_SOC3 ADC_SOC_NUMBER3
#define ADCC_inst_FORCE_SOC3 ADC_FORCE_SOC3
#define ADCC_inst_SAMPLE_WINDOW_SOC3 2500
#define ADCC_inst_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_SW_ONLY
#define ADCC_inst_CHANNEL_SOC3 ADC_CH_ADCIN3
#define ADCC_inst_SOC4 ADC_SOC_NUMBER4
#define ADCC_inst_FORCE_SOC4 ADC_FORCE_SOC4
#define ADCC_inst_SAMPLE_WINDOW_SOC4 2500
#define ADCC_inst_TRIGGER_SOURCE_SOC4 ADC_TRIGGER_SW_ONLY
#define ADCC_inst_CHANNEL_SOC4 ADC_CH_ADCIN4
#define ADCC_inst_SOC5 ADC_SOC_NUMBER5
#define ADCC_inst_FORCE_SOC5 ADC_FORCE_SOC5
#define ADCC_inst_SAMPLE_WINDOW_SOC5 2500
#define ADCC_inst_TRIGGER_SOURCE_SOC5 ADC_TRIGGER_SW_ONLY
#define ADCC_inst_CHANNEL_SOC5 ADC_CH_ADCIN5
void ADCC_inst_init();

#define ADCD_inst_BASE ADCD_BASE
#define ADCD_inst_RESULT_BASE ADCDRESULT_BASE
#define ADCD_inst_SOC0 ADC_SOC_NUMBER0
#define ADCD_inst_FORCE_SOC0 ADC_FORCE_SOC0
#define ADCD_inst_SAMPLE_WINDOW_SOC0 2500
#define ADCD_inst_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_SW_ONLY
#define ADCD_inst_CHANNEL_SOC0 ADC_CH_ADCIN0
#define ADCD_inst_SOC1 ADC_SOC_NUMBER1
#define ADCD_inst_FORCE_SOC1 ADC_FORCE_SOC1
#define ADCD_inst_SAMPLE_WINDOW_SOC1 2500
#define ADCD_inst_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_SW_ONLY
#define ADCD_inst_CHANNEL_SOC1 ADC_CH_ADCIN1
#define ADCD_inst_SOC2 ADC_SOC_NUMBER2
#define ADCD_inst_FORCE_SOC2 ADC_FORCE_SOC2
#define ADCD_inst_SAMPLE_WINDOW_SOC2 2500
#define ADCD_inst_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_SW_ONLY
#define ADCD_inst_CHANNEL_SOC2 ADC_CH_ADCIN2
#define ADCD_inst_SOC3 ADC_SOC_NUMBER3
#define ADCD_inst_FORCE_SOC3 ADC_FORCE_SOC3
#define ADCD_inst_SAMPLE_WINDOW_SOC3 2500
#define ADCD_inst_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_SW_ONLY
#define ADCD_inst_CHANNEL_SOC3 ADC_CH_ADCIN3
#define ADCD_inst_SOC4 ADC_SOC_NUMBER4
#define ADCD_inst_FORCE_SOC4 ADC_FORCE_SOC4
#define ADCD_inst_SAMPLE_WINDOW_SOC4 2500
#define ADCD_inst_TRIGGER_SOURCE_SOC4 ADC_TRIGGER_SW_ONLY
#define ADCD_inst_CHANNEL_SOC4 ADC_CH_ADCIN4
#define ADCD_inst_SOC5 ADC_SOC_NUMBER5
#define ADCD_inst_FORCE_SOC5 ADC_FORCE_SOC5
#define ADCD_inst_SAMPLE_WINDOW_SOC5 2500
#define ADCD_inst_TRIGGER_SOURCE_SOC5 ADC_TRIGGER_SW_ONLY
#define ADCD_inst_CHANNEL_SOC5 ADC_CH_ADCIN5
void ADCD_inst_init();


//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
#define CPUTIMER0_inst_BASE CPUTIMER0_BASE
void CPUTIMER0_inst_init();
#define CPUTIMER1_inst_BASE CPUTIMER1_BASE
void CPUTIMER1_inst_init();

//*****************************************************************************
//
// DAC Configurations
//
//*****************************************************************************
#define DACA_inst_BASE DACA_BASE
void DACA_inst_init();
#define DACB_inst_BASE DACB_BASE
void DACB_inst_init();
#define DACC_inst_BASE DACC_BASE
void DACC_inst_init();

//*****************************************************************************
//
// DMA Configurations
//
//*****************************************************************************
extern const void *ADCA_ResultRegisterPtr;
extern const void *ADCA_ResultBufferPtr;
#define DMA1_inst_BASE DMA_CH1_BASE 
#define DMA1_inst_BURSTSIZE 16U
#define DMA1_inst_TRANSFERSIZE 256U
#define DMA1_inst_SRC_WRAPSIZE 65536U
#define DMA1_inst_DEST_WRAPSIZE 65536U
void DMA1_inst_init();
extern const void *ADCB_ResultRegisterPtr;
extern const void *ADCB_ResultBufferPtr;
#define DMA2_inst_BASE DMA_CH2_BASE 
#define DMA2_inst_BURSTSIZE 16U
#define DMA2_inst_TRANSFERSIZE 256U
#define DMA2_inst_SRC_WRAPSIZE 65536U
#define DMA2_inst_DEST_WRAPSIZE 65536U
void DMA2_inst_init();
extern const void *ADCC_ResultRegisterPtr;
extern const void *ADCC_ResultBufferPtr;
#define DMA3_inst_BASE DMA_CH3_BASE 
#define DMA3_inst_BURSTSIZE 16U
#define DMA3_inst_TRANSFERSIZE 256U
#define DMA3_inst_SRC_WRAPSIZE 65536U
#define DMA3_inst_DEST_WRAPSIZE 65536U
void DMA3_inst_init();
extern const void *ADCD_ResultRegisterPtr;
extern const void *ADCD_ResultBufferPtr;
#define DMA4_inst_BASE DMA_CH4_BASE 
#define DMA4_inst_BURSTSIZE 16U
#define DMA4_inst_TRANSFERSIZE 256U
#define DMA4_inst_SRC_WRAPSIZE 65536U
#define DMA4_inst_DEST_WRAPSIZE 65536U
void DMA4_inst_init();

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define LED1_GPIO 18
void LED1_GPIO_init();
#define LED2_GPIO 17
void LED2_GPIO_init();
#define LED3_GPIO 16
void LED3_GPIO_init();
#define LED4_GPIO 19
void LED4_GPIO_init();
#define inst_GPIO2 2
void inst_GPIO2_init();
#define inst_GPIO3 3
void inst_GPIO3_init();
#define inst_GPIO4 4
void inst_GPIO4_init();
#define inst_GPIO5 5
void inst_GPIO5_init();
#define inst_GPIO6 6
void inst_GPIO6_init();
#define inst_GPIO7 7
void inst_GPIO7_init();
#define inst_GPIO8 8
void inst_GPIO8_init();
#define inst_GPIO9 9
void inst_GPIO9_init();
#define inst_GPIO11 11
void inst_GPIO11_init();
#define inst_GPIO12 12
void inst_GPIO12_init();
#define inst_GPIO13 13
void inst_GPIO13_init();
#define inst_GPIO14 14
void inst_GPIO14_init();
#define inst_GPIO15 15
void inst_GPIO15_init();
#define inst_GPIO10 10
void inst_GPIO10_init();
#define inst_GPIO20 20
void inst_GPIO20_init();
#define inst_GPIO21 21
void inst_GPIO21_init();
#define inst_GPIO22 22
void inst_GPIO22_init();
#define inst_GPIO23 23
void inst_GPIO23_init();
#define inst_GPIO24 24
void inst_GPIO24_init();
#define inst_GPIO25 25
void inst_GPIO25_init();
#define inst_GPIO26 26
void inst_GPIO26_init();
#define inst_GPIO27 27
void inst_GPIO27_init();
#define inst_GPIO30 30
void inst_GPIO30_init();
#define inst_GPIO32 32
void inst_GPIO32_init();
#define inst_GPIO33 33
void inst_GPIO33_init();
#define inst_GPIO36 36
void inst_GPIO36_init();
#define inst_GPIO43 43
void inst_GPIO43_init();
#define inst_GPIO53 53
void inst_GPIO53_init();
#define inst_GPIO54 54
void inst_GPIO54_init();
#define inst_GPIO55 55
void inst_GPIO55_init();
#define inst_GPIO56 56
void inst_GPIO56_init();
#define inst_GPIO57 57
void inst_GPIO57_init();
#define inst_GPIO62 62
void inst_GPIO62_init();
#define inst_GPIO63 63
void inst_GPIO63_init();
#define inst_GPIO64 64
void inst_GPIO64_init();
#define inst_GPIO65 65
void inst_GPIO65_init();
#define inst_GPIO66 66
void inst_GPIO66_init();
#define inst_GPIO84 84
void inst_GPIO84_init();
#define inst_GPIO93 93
void inst_GPIO93_init();
#define inst_GPIO94 94
void inst_GPIO94_init();
#define inst_GPIO95 95
void inst_GPIO95_init();
#define inst_GPIO96 96
void inst_GPIO96_init();
#define inst_GPIO97 97
void inst_GPIO97_init();
#define inst_GPIO98 98
void inst_GPIO98_init();
#define inst_GPIO99 99
void inst_GPIO99_init();
#define inst_GPIO100 100
void inst_GPIO100_init();
#define inst_GPIO101 101
void inst_GPIO101_init();
#define inst_GPIO102 102
void inst_GPIO102_init();
#define inst_GPIO103 103
void inst_GPIO103_init();
#define inst_GPIO104 104
void inst_GPIO104_init();
#define inst_GPIO105 105
void inst_GPIO105_init();
#define inst_GPIO108 108
void inst_GPIO108_init();
#define inst_GPIO110 110
void inst_GPIO110_init();
#define inst_GPIO111 111
void inst_GPIO111_init();
#define inst_GPIO119 119
void inst_GPIO119_init();
#define inst_GPIO125 125
void inst_GPIO125_init();
#define inst_GPIO126 126
void inst_GPIO126_init();
#define inst_GPIO127 127
void inst_GPIO127_init();
#define inst_GPIO128 128
void inst_GPIO128_init();
#define inst_GPIO129 129
void inst_GPIO129_init();
#define inst_GPIO130 130
void inst_GPIO130_init();
#define inst_GPIO131 131
void inst_GPIO131_init();
#define inst_GPIO132 132
void inst_GPIO132_init();
#define inst_GPIO133 133
void inst_GPIO133_init();
#define inst_GPIO134 134
void inst_GPIO134_init();
#define inst_GPIO135 135
void inst_GPIO135_init();
#define inst_GPIO136 136
void inst_GPIO136_init();
#define inst_GPIO137 137
void inst_GPIO137_init();
#define inst_GPIO138 138
void inst_GPIO138_init();
#define inst_GPIO139 139
void inst_GPIO139_init();
#define inst_GPIO140 140
void inst_GPIO140_init();
#define inst_GPIO141 141
void inst_GPIO141_init();
#define inst_GPIO142 142
void inst_GPIO142_init();
#define inst_GPIO143 143
void inst_GPIO143_init();
#define inst_GPIO144 144
void inst_GPIO144_init();
#define inst_GPIO145 145
void inst_GPIO145_init();
#define inst_GPIO146 146
void inst_GPIO146_init();
#define inst_GPIO147 147
void inst_GPIO147_init();
#define inst_GPIO148 148
void inst_GPIO148_init();
#define inst_GPIO149 149
void inst_GPIO149_init();
#define inst_GPIO150 150
void inst_GPIO150_init();
#define inst_GPIO151 151
void inst_GPIO151_init();
#define inst_GPIO152 152
void inst_GPIO152_init();
#define inst_GPIO153 153
void inst_GPIO153_init();
#define inst_GPIO154 154
void inst_GPIO154_init();
#define inst_GPIO155 155
void inst_GPIO155_init();
#define inst_GPIO156 156
void inst_GPIO156_init();
#define inst_GPIO157 157
void inst_GPIO157_init();
#define inst_GPIO158 158
void inst_GPIO158_init();
#define inst_GPIO159 159
void inst_GPIO159_init();
#define inst_GPIO160 160
void inst_GPIO160_init();
#define inst_GPIO161 161
void inst_GPIO161_init();
#define inst_GPIO162 162
void inst_GPIO162_init();
#define inst_GPIO163 163
void inst_GPIO163_init();
#define inst_GPIO164 164
void inst_GPIO164_init();
#define inst_GPIO165 165
void inst_GPIO165_init();
#define inst_GPIO166 166
void inst_GPIO166_init();
#define inst_GPIO167 167
void inst_GPIO167_init();
#define inst_GPIO168 168
void inst_GPIO168_init();
#define inst_GPIO72 72
void inst_GPIO72_init();

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************

// Interrupt Settings for INT_ADCA_inst_1
// ISR need to be defined for the registered interrupts
#define INT_ADCA_inst_1 INT_ADCA1
#define INT_ADCA_inst_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_ADCA_inst_1_ISR(void);

// Interrupt Settings for INT_ADCA_inst_2
// ISR need to be defined for the registered interrupts
#define INT_ADCA_inst_2 INT_ADCA2
#define INT_ADCA_inst_2_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCA_inst_2_ISR(void);

// Interrupt Settings for INT_ADCA_inst_3
// ISR need to be defined for the registered interrupts
#define INT_ADCA_inst_3 INT_ADCA3
#define INT_ADCA_inst_3_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCA_inst_3_ISR(void);

// Interrupt Settings for INT_ADCA_inst_4
// ISR need to be defined for the registered interrupts
#define INT_ADCA_inst_4 INT_ADCA4
#define INT_ADCA_inst_4_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCA_inst_4_ISR(void);

// Interrupt Settings for INT_ADCB_inst_1
// ISR need to be defined for the registered interrupts
#define INT_ADCB_inst_1 INT_ADCB1
#define INT_ADCB_inst_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_ADCB_inst_1_ISR(void);

// Interrupt Settings for INT_ADCB_inst_2
// ISR need to be defined for the registered interrupts
#define INT_ADCB_inst_2 INT_ADCB2
#define INT_ADCB_inst_2_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCB_inst_2_ISR(void);

// Interrupt Settings for INT_ADCB_inst_3
// ISR need to be defined for the registered interrupts
#define INT_ADCB_inst_3 INT_ADCB3
#define INT_ADCB_inst_3_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCB_inst_3_ISR(void);

// Interrupt Settings for INT_ADCB_inst_4
// ISR need to be defined for the registered interrupts
#define INT_ADCB_inst_4 INT_ADCB4
#define INT_ADCB_inst_4_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCB_inst_4_ISR(void);

// Interrupt Settings for INT_ADCC_inst_1
// ISR need to be defined for the registered interrupts
#define INT_ADCC_inst_1 INT_ADCC1
#define INT_ADCC_inst_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_ADCC_inst_1_ISR(void);

// Interrupt Settings for INT_ADCC_inst_2
// ISR need to be defined for the registered interrupts
#define INT_ADCC_inst_2 INT_ADCC2
#define INT_ADCC_inst_2_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCC_inst_2_ISR(void);

// Interrupt Settings for INT_ADCC_inst_3
// ISR need to be defined for the registered interrupts
#define INT_ADCC_inst_3 INT_ADCC3
#define INT_ADCC_inst_3_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCC_inst_3_ISR(void);

// Interrupt Settings for INT_ADCC_inst_4
// ISR need to be defined for the registered interrupts
#define INT_ADCC_inst_4 INT_ADCC4
#define INT_ADCC_inst_4_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCC_inst_4_ISR(void);

// Interrupt Settings for INT_ADCD_inst_1
// ISR need to be defined for the registered interrupts
#define INT_ADCD_inst_1 INT_ADCD1
#define INT_ADCD_inst_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_ADCD_inst_1_ISR(void);

// Interrupt Settings for INT_ADCD_inst_2
// ISR need to be defined for the registered interrupts
#define INT_ADCD_inst_2 INT_ADCD2
#define INT_ADCD_inst_2_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCD_inst_2_ISR(void);

// Interrupt Settings for INT_ADCD_inst_3
// ISR need to be defined for the registered interrupts
#define INT_ADCD_inst_3 INT_ADCD3
#define INT_ADCD_inst_3_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCD_inst_3_ISR(void);

// Interrupt Settings for INT_ADCD_inst_4
// ISR need to be defined for the registered interrupts
#define INT_ADCD_inst_4 INT_ADCD4
#define INT_ADCD_inst_4_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP10
extern __interrupt void INT_ADCD_inst_4_ISR(void);

// Interrupt Settings for INT_CPUTIMER0_inst
// ISR need to be defined for the registered interrupts
#define INT_CPUTIMER0_inst INT_TIMER0
#define INT_CPUTIMER0_inst_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_CPUTIMER0_inst_ISR(void);

// Interrupt Settings for INT_DMA1_inst
// ISR need to be defined for the registered interrupts
#define INT_DMA1_inst INT_DMA_CH1
#define INT_DMA1_inst_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP7
extern __interrupt void INT_DMA1_inst_ISR(void);

// Interrupt Settings for INT_DMA2_inst
// ISR need to be defined for the registered interrupts
#define INT_DMA2_inst INT_DMA_CH2
#define INT_DMA2_inst_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP7
extern __interrupt void INT_DMA2_inst_ISR(void);

// Interrupt Settings for INT_DMA3_inst
// ISR need to be defined for the registered interrupts
#define INT_DMA3_inst INT_DMA_CH3
#define INT_DMA3_inst_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP7
extern __interrupt void INT_DMA3_inst_ISR(void);

// Interrupt Settings for INT_DMA4_inst
// ISR need to be defined for the registered interrupts
#define INT_DMA4_inst INT_DMA_CH4
#define INT_DMA4_inst_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP7
extern __interrupt void INT_DMA4_inst_ISR(void);

// Interrupt Settings for INT_SCIA_inst_RX
// ISR need to be defined for the registered interrupts
#define INT_SCIA_inst_RX INT_SCIA_RX
#define INT_SCIA_inst_RX_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP9
extern __interrupt void INT_SCIA_inst_RX_ISR(void);

// Interrupt Settings for INT_SCIA_inst_TX
// ISR need to be defined for the registered interrupts
#define INT_SCIA_inst_TX INT_SCIA_TX
#define INT_SCIA_inst_TX_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP9
extern __interrupt void INT_SCIA_inst_TX_ISR(void);

//*****************************************************************************
//
// SCI Configurations
//
//*****************************************************************************
#define SCIA_inst_BASE SCIA_BASE
#define SCIA_inst_BAUDRATE 115200
#define SCIA_inst_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define SCIA_inst_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define SCIA_inst_CONFIG_PAR SCI_CONFIG_PAR_EVEN
#define SCIA_inst_FIFO_TX_LVL SCI_FIFO_TX0
#define SCIA_inst_FIFO_RX_LVL SCI_FIFO_RX1
void SCIA_inst_init();

//*****************************************************************************
//
// SYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	CPUTIMER_init();
void	DAC_init();
void	DMA_init();
void	GPIO_init();
void	INTERRUPT_init();
void	SCI_init();
void	SYSCTL_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
