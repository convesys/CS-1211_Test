/*
 * appl_gpio.h
 *
 *  Created on: 13.09.2025
 *      Author: Dimitar Lilov
 */

#ifndef APPL_APPL_GPIO_H_
#define APPL_APPL_GPIO_H_

void APPL_GPIO_Fill(void);

#endif /* APPL_APPL_GPIO_H_ */
