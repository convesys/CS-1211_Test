/*
 * appl_adc_dma.h
 *
 *  Created on: 13.09.2025
 *      Author: Dimitar Lilov
 */

#ifndef APPL_APPL_ADC_DMA_H_
#define APPL_APPL_ADC_DMA_H_



#endif /* APPL_APPL_ADC_DMA_H_ */
