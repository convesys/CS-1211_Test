/*
 * appl_sci.h
 *
 *  Created on: 13.09.2025
 *      Author: Dimitar Lilov
 */

#ifndef APPL_APPL_SCI_H_
#define APPL_APPL_SCI_H_



#endif /* APPL_APPL_SCI_H_ */
