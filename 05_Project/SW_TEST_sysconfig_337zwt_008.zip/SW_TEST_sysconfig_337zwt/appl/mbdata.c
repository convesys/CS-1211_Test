#include <stdint.h>
#include "mbdata.h"

uint16_t hold_reg_mem[HR_CNT + HR_CTR_CNT];
//uint16_t inp_reg_mem[IR_CNT];



void MBDATA_Init(void){
}


