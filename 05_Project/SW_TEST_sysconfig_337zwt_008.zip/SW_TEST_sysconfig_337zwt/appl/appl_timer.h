/*
 * appl_timer.h
 *
 *  Created on: 13.09.2025
 *      Author: Dimitar Lilov
 */

#ifndef APPL_APPL_TIMER_H_
#define APPL_APPL_TIMER_H_

void APPL_TIMER_200ms_Generation(void);

#endif /* APPL_APPL_TIMER_H_ */
