#ifndef MBPROT_H
#define MBPROT_H

// Section: Included Files

void MB_Main(void);
void MB_Check_Tmr(void);
void MBTXInterrupt(void);
void MBRXInterrupt(void);

#endif  // MBPROT_H

