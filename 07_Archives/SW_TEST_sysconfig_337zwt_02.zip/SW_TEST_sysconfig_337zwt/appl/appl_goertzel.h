/*
 * appl_goertzel.h
 *
 *  Created on: 13.09.2025
 *      Author: Dimitar Lilov
 */

#ifndef APPL_APPL_GOERTZEL_H_
#define APPL_APPL_GOERTZEL_H_



#endif /* APPL_APPL_GOERTZEL_H_ */
