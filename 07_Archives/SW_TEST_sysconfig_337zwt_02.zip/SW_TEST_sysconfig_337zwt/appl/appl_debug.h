/*
 * appl_debug.h
 *
 *  Created on: 13.09.2025
 *      Author: Dimitar Lilov
 */

#ifndef APPL_APPL_DEBUG_H_
#define APPL_APPL_DEBUG_H_

#include <stdint.h>

extern uint16_t APPL_DEBUG_ui16_snd_cntr;

void APPL_DEBUG_sci_test_print(void);

#endif /* APPL_APPL_DEBUG_H_ */
