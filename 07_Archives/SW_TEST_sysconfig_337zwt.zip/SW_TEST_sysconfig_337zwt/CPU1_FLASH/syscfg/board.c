/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules. 
// Call this function in your application if you wish to do all module 
// initialization.
// If you wish to not use some of the initializations, instead of the 
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
	EALLOW;

	PinMux_init();
	SYSCTL_init();
	ADC_init();
	CPUTIMER_init();
	GPIO_init();
	SCI_init();
	INTERRUPT_init();

	EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
	//
	// PinMux for modules assigned to CPU1
	//
	
	// GPIO18 -> LED1_GPIO Pinmux
	GPIO_setPinConfig(GPIO_18_GPIO18);
	// GPIO17 -> LED2_GPIO Pinmux
	GPIO_setPinConfig(GPIO_17_GPIO17);
	// GPIO16 -> LED3_GPIO Pinmux
	GPIO_setPinConfig(GPIO_16_GPIO16);
	// GPIO19 -> LED4_GPIO Pinmux
	GPIO_setPinConfig(GPIO_19_GPIO19);
	// GPIO2 -> inst_GPIO2 Pinmux
	GPIO_setPinConfig(GPIO_2_GPIO2);
	// GPIO3 -> inst_GPIO3 Pinmux
	GPIO_setPinConfig(GPIO_3_GPIO3);
	// GPIO4 -> inst_GPIO4 Pinmux
	GPIO_setPinConfig(GPIO_4_GPIO4);
	// GPIO5 -> inst_GPIO5 Pinmux
	GPIO_setPinConfig(GPIO_5_GPIO5);
	// GPIO6 -> inst_GPIO6 Pinmux
	GPIO_setPinConfig(GPIO_6_GPIO6);
	// GPIO7 -> inst_GPIO7 Pinmux
	GPIO_setPinConfig(GPIO_7_GPIO7);
	// GPIO8 -> inst_GPIO8 Pinmux
	GPIO_setPinConfig(GPIO_8_GPIO8);
	// GPIO9 -> inst_GPIO9 Pinmux
	GPIO_setPinConfig(GPIO_9_GPIO9);
	// GPIO11 -> inst_GPIO11 Pinmux
	GPIO_setPinConfig(GPIO_11_GPIO11);
	// GPIO12 -> inst_GPIO12 Pinmux
	GPIO_setPinConfig(GPIO_12_GPIO12);
	// GPIO13 -> inst_GPIO13 Pinmux
	GPIO_setPinConfig(GPIO_13_GPIO13);
	// GPIO14 -> inst_GPIO14 Pinmux
	GPIO_setPinConfig(GPIO_14_GPIO14);
	// GPIO15 -> inst_GPIO15 Pinmux
	GPIO_setPinConfig(GPIO_15_GPIO15);
	// GPIO10 -> inst_GPIO10 Pinmux
	GPIO_setPinConfig(GPIO_10_GPIO10);
	// GPIO20 -> inst_GPIO20 Pinmux
	GPIO_setPinConfig(GPIO_20_GPIO20);
	// GPIO21 -> inst_GPIO21 Pinmux
	GPIO_setPinConfig(GPIO_21_GPIO21);
	// GPIO22 -> inst_GPIO22 Pinmux
	GPIO_setPinConfig(GPIO_22_GPIO22);
	// GPIO23 -> inst_GPIO23 Pinmux
	GPIO_setPinConfig(GPIO_23_GPIO23);
	// GPIO24 -> inst_GPIO24 Pinmux
	GPIO_setPinConfig(GPIO_24_GPIO24);
	// GPIO25 -> inst_GPIO25 Pinmux
	GPIO_setPinConfig(GPIO_25_GPIO25);
	// GPIO26 -> inst_GPIO26 Pinmux
	GPIO_setPinConfig(GPIO_26_GPIO26);
	// GPIO27 -> inst_GPIO27 Pinmux
	GPIO_setPinConfig(GPIO_27_GPIO27);
	// GPIO30 -> inst_GPIO30 Pinmux
	GPIO_setPinConfig(GPIO_30_GPIO30);
	// GPIO32 -> inst_GPIO32 Pinmux
	GPIO_setPinConfig(GPIO_32_GPIO32);
	// GPIO33 -> inst_GPIO33 Pinmux
	GPIO_setPinConfig(GPIO_33_GPIO33);
	// GPIO36 -> inst_GPIO36 Pinmux
	GPIO_setPinConfig(GPIO_36_GPIO36);
	// GPIO43 -> inst_GPIO43 Pinmux
	GPIO_setPinConfig(GPIO_43_GPIO43);
	// GPIO53 -> inst_GPIO53 Pinmux
	GPIO_setPinConfig(GPIO_53_GPIO53);
	// GPIO54 -> inst_GPIO54 Pinmux
	GPIO_setPinConfig(GPIO_54_GPIO54);
	// GPIO55 -> inst_GPIO55 Pinmux
	GPIO_setPinConfig(GPIO_55_GPIO55);
	// GPIO56 -> inst_GPIO56 Pinmux
	GPIO_setPinConfig(GPIO_56_GPIO56);
	// GPIO57 -> inst_GPIO57 Pinmux
	GPIO_setPinConfig(GPIO_57_GPIO57);
	// GPIO62 -> inst_GPIO62 Pinmux
	GPIO_setPinConfig(GPIO_62_GPIO62);
	// GPIO63 -> inst_GPIO63 Pinmux
	GPIO_setPinConfig(GPIO_63_GPIO63);
	// GPIO64 -> inst_GPIO64 Pinmux
	GPIO_setPinConfig(GPIO_64_GPIO64);
	// GPIO65 -> inst_GPIO65 Pinmux
	GPIO_setPinConfig(GPIO_65_GPIO65);
	// GPIO66 -> inst_GPIO66 Pinmux
	GPIO_setPinConfig(GPIO_66_GPIO66);
	// GPIO84 -> inst_GPIO84 Pinmux
	GPIO_setPinConfig(GPIO_84_GPIO84);
	// GPIO93 -> inst_GPIO93 Pinmux
	GPIO_setPinConfig(GPIO_93_GPIO93);
	// GPIO94 -> inst_GPIO94 Pinmux
	GPIO_setPinConfig(GPIO_94_GPIO94);
	// GPIO95 -> inst_GPIO95 Pinmux
	GPIO_setPinConfig(GPIO_95_GPIO95);
	// GPIO96 -> inst_GPIO96 Pinmux
	GPIO_setPinConfig(GPIO_96_GPIO96);
	// GPIO97 -> inst_GPIO97 Pinmux
	GPIO_setPinConfig(GPIO_97_GPIO97);
	// GPIO98 -> inst_GPIO98 Pinmux
	GPIO_setPinConfig(GPIO_98_GPIO98);
	// GPIO99 -> inst_GPIO99 Pinmux
	GPIO_setPinConfig(GPIO_99_GPIO99);
	// GPIO100 -> inst_GPIO100 Pinmux
	GPIO_setPinConfig(GPIO_100_GPIO100);
	// GPIO101 -> inst_GPIO101 Pinmux
	GPIO_setPinConfig(GPIO_101_GPIO101);
	// GPIO102 -> inst_GPIO102 Pinmux
	GPIO_setPinConfig(GPIO_102_GPIO102);
	// GPIO103 -> inst_GPIO103 Pinmux
	GPIO_setPinConfig(GPIO_103_GPIO103);
	// GPIO104 -> inst_GPIO104 Pinmux
	GPIO_setPinConfig(GPIO_104_GPIO104);
	// GPIO105 -> inst_GPIO105 Pinmux
	GPIO_setPinConfig(GPIO_105_GPIO105);
	// GPIO108 -> inst_GPIO108 Pinmux
	GPIO_setPinConfig(GPIO_108_GPIO108);
	// GPIO110 -> inst_GPIO110 Pinmux
	GPIO_setPinConfig(GPIO_110_GPIO110);
	// GPIO111 -> inst_GPIO111 Pinmux
	GPIO_setPinConfig(GPIO_111_GPIO111);
	// GPIO119 -> inst_GPIO119 Pinmux
	GPIO_setPinConfig(GPIO_119_GPIO119);
	// GPIO125 -> inst_GPIO125 Pinmux
	GPIO_setPinConfig(GPIO_125_GPIO125);
	// GPIO126 -> inst_GPIO126 Pinmux
	GPIO_setPinConfig(GPIO_126_GPIO126);
	// GPIO127 -> inst_GPIO127 Pinmux
	GPIO_setPinConfig(GPIO_127_GPIO127);
	// GPIO128 -> inst_GPIO128 Pinmux
	GPIO_setPinConfig(GPIO_128_GPIO128);
	// GPIO129 -> inst_GPIO129 Pinmux
	GPIO_setPinConfig(GPIO_129_GPIO129);
	// GPIO130 -> inst_GPIO130 Pinmux
	GPIO_setPinConfig(GPIO_130_GPIO130);
	// GPIO131 -> inst_GPIO131 Pinmux
	GPIO_setPinConfig(GPIO_131_GPIO131);
	// GPIO132 -> inst_GPIO132 Pinmux
	GPIO_setPinConfig(GPIO_132_GPIO132);
	// GPIO133 -> inst_GPIO133 Pinmux
	GPIO_setPinConfig(GPIO_133_GPIO133);
	// GPIO134 -> inst_GPIO134 Pinmux
	GPIO_setPinConfig(GPIO_134_GPIO134);
	// GPIO135 -> inst_GPIO135 Pinmux
	GPIO_setPinConfig(GPIO_135_GPIO135);
	// GPIO136 -> inst_GPIO136 Pinmux
	GPIO_setPinConfig(GPIO_136_GPIO136);
	// GPIO137 -> inst_GPIO137 Pinmux
	GPIO_setPinConfig(GPIO_137_GPIO137);
	// GPIO138 -> inst_GPIO138 Pinmux
	GPIO_setPinConfig(GPIO_138_GPIO138);
	// GPIO139 -> inst_GPIO139 Pinmux
	GPIO_setPinConfig(GPIO_139_GPIO139);
	// GPIO140 -> inst_GPIO140 Pinmux
	GPIO_setPinConfig(GPIO_140_GPIO140);
	// GPIO141 -> inst_GPIO141 Pinmux
	GPIO_setPinConfig(GPIO_141_GPIO141);
	// GPIO142 -> inst_GPIO142 Pinmux
	GPIO_setPinConfig(GPIO_142_GPIO142);
	// GPIO143 -> inst_GPIO143 Pinmux
	GPIO_setPinConfig(GPIO_143_GPIO143);
	// GPIO144 -> inst_GPIO144 Pinmux
	GPIO_setPinConfig(GPIO_144_GPIO144);
	// GPIO145 -> inst_GPIO145 Pinmux
	GPIO_setPinConfig(GPIO_145_GPIO145);
	// GPIO146 -> inst_GPIO146 Pinmux
	GPIO_setPinConfig(GPIO_146_GPIO146);
	// GPIO147 -> inst_GPIO147 Pinmux
	GPIO_setPinConfig(GPIO_147_GPIO147);
	// GPIO148 -> inst_GPIO148 Pinmux
	GPIO_setPinConfig(GPIO_148_GPIO148);
	// GPIO149 -> inst_GPIO149 Pinmux
	GPIO_setPinConfig(GPIO_149_GPIO149);
	// GPIO150 -> inst_GPIO150 Pinmux
	GPIO_setPinConfig(GPIO_150_GPIO150);
	// GPIO151 -> inst_GPIO151 Pinmux
	GPIO_setPinConfig(GPIO_151_GPIO151);
	// GPIO152 -> inst_GPIO152 Pinmux
	GPIO_setPinConfig(GPIO_152_GPIO152);
	// GPIO153 -> inst_GPIO153 Pinmux
	GPIO_setPinConfig(GPIO_153_GPIO153);
	// GPIO154 -> inst_GPIO154 Pinmux
	GPIO_setPinConfig(GPIO_154_GPIO154);
	// GPIO155 -> inst_GPIO155 Pinmux
	GPIO_setPinConfig(GPIO_155_GPIO155);
	// GPIO156 -> inst_GPIO156 Pinmux
	GPIO_setPinConfig(GPIO_156_GPIO156);
	// GPIO157 -> inst_GPIO157 Pinmux
	GPIO_setPinConfig(GPIO_157_GPIO157);
	// GPIO158 -> inst_GPIO158 Pinmux
	GPIO_setPinConfig(GPIO_158_GPIO158);
	// GPIO159 -> inst_GPIO159 Pinmux
	GPIO_setPinConfig(GPIO_159_GPIO159);
	// GPIO160 -> inst_GPIO160 Pinmux
	GPIO_setPinConfig(GPIO_160_GPIO160);
	// GPIO161 -> inst_GPIO161 Pinmux
	GPIO_setPinConfig(GPIO_161_GPIO161);
	// GPIO162 -> inst_GPIO162 Pinmux
	GPIO_setPinConfig(GPIO_162_GPIO162);
	// GPIO163 -> inst_GPIO163 Pinmux
	GPIO_setPinConfig(GPIO_163_GPIO163);
	// GPIO164 -> inst_GPIO164 Pinmux
	GPIO_setPinConfig(GPIO_164_GPIO164);
	// GPIO165 -> inst_GPIO165 Pinmux
	GPIO_setPinConfig(GPIO_165_GPIO165);
	// GPIO166 -> inst_GPIO166 Pinmux
	GPIO_setPinConfig(GPIO_166_GPIO166);
	// GPIO167 -> inst_GPIO167 Pinmux
	GPIO_setPinConfig(GPIO_167_GPIO167);
	// GPIO168 -> inst_GPIO168 Pinmux
	GPIO_setPinConfig(GPIO_168_GPIO168);
	// GPIO72 -> inst_GPIO72 Pinmux
	GPIO_setPinConfig(GPIO_72_GPIO72);
	//
	// SCIA -> SCIA_inst Pinmux
	//
	GPIO_setPinConfig(SCIA_inst_SCIRX_PIN_CONFIG);
	GPIO_setPadConfig(SCIA_inst_SCIRX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(SCIA_inst_SCIRX_GPIO, GPIO_QUAL_3SAMPLE);

	GPIO_setPinConfig(SCIA_inst_SCITX_PIN_CONFIG);
	GPIO_setPadConfig(SCIA_inst_SCITX_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SCIA_inst_SCITX_GPIO, GPIO_QUAL_3SAMPLE);


}

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
void ADC_init(){
	ADCA_inst_init();
	ADCB_inst_init();
	ADCC_inst_init();
	ADCD_inst_init();
}

void ADCA_inst_init(){
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(ADCA_inst_BASE, ADC_CLK_DIV_4_0);
	//
	// Configures the analog-to-digital converter resolution and signal mode.
	//
	ADC_setMode(ADCA_inst_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(ADCA_inst_BASE, ADC_PULSE_END_OF_CONV);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(ADCA_inst_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(ADCA_inst_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(ADCA_inst_BASE, ADC_PRI_ALL_HIPRI);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN0
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCA_inst_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN0, 500U);
	ADC_setInterruptSOCTrigger(ADCA_inst_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCA_inst_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN1, 500U);
	ADC_setInterruptSOCTrigger(ADCA_inst_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCA_inst_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 500U);
	ADC_setInterruptSOCTrigger(ADCA_inst_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 3 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCA_inst_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN3, 500U);
	ADC_setInterruptSOCTrigger(ADCA_inst_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 4 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCA_inst_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN4, 500U);
	ADC_setInterruptSOCTrigger(ADCA_inst_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 5 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 5
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCA_inst_BASE, ADC_SOC_NUMBER5, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN5, 500U);
	ADC_setInterruptSOCTrigger(ADCA_inst_BASE, ADC_SOC_NUMBER5, ADC_INT_SOC_TRIGGER_NONE);
	//
	// ADC Interrupt 1 Configuration
	// 		Source	: ADC_SOC_NUMBER0
	// 		Interrupt Source: disabled
	// 		Continuous Mode	: disabled
	//
	//
	ADC_setInterruptSource(ADCA_inst_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
	ADC_disableContinuousMode(ADCA_inst_BASE, ADC_INT_NUMBER1);
	ADC_disableInterrupt(ADCA_inst_BASE, ADC_INT_NUMBER1);
}

void ADCB_inst_init(){
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(ADCB_inst_BASE, ADC_CLK_DIV_4_0);
	//
	// Configures the analog-to-digital converter resolution and signal mode.
	//
	ADC_setMode(ADCB_inst_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(ADCB_inst_BASE, ADC_PULSE_END_OF_CONV);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(ADCB_inst_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(ADCB_inst_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(ADCB_inst_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN0
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCB_inst_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN0, 500U);
	ADC_setInterruptSOCTrigger(ADCB_inst_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCB_inst_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN1, 500U);
	ADC_setInterruptSOCTrigger(ADCB_inst_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCB_inst_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 500U);
	ADC_setInterruptSOCTrigger(ADCB_inst_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 3 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCB_inst_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN3, 500U);
	ADC_setInterruptSOCTrigger(ADCB_inst_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 4 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCB_inst_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN4, 500U);
	ADC_setInterruptSOCTrigger(ADCB_inst_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 5 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 5
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCB_inst_BASE, ADC_SOC_NUMBER5, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN5, 500U);
	ADC_setInterruptSOCTrigger(ADCB_inst_BASE, ADC_SOC_NUMBER5, ADC_INT_SOC_TRIGGER_NONE);
	//
	// ADC Interrupt 1 Configuration
	// 		Source	: ADC_SOC_NUMBER0
	// 		Interrupt Source: disabled
	// 		Continuous Mode	: disabled
	//
	//
	ADC_setInterruptSource(ADCB_inst_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
	ADC_disableContinuousMode(ADCB_inst_BASE, ADC_INT_NUMBER1);
	ADC_disableInterrupt(ADCB_inst_BASE, ADC_INT_NUMBER1);
}

void ADCC_inst_init(){
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(ADCC_inst_BASE, ADC_CLK_DIV_4_0);
	//
	// Configures the analog-to-digital converter resolution and signal mode.
	//
	ADC_setMode(ADCC_inst_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(ADCC_inst_BASE, ADC_PULSE_END_OF_CONV);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(ADCC_inst_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(ADCC_inst_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(ADCC_inst_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN14
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCC_inst_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN14, 500U);
	ADC_setInterruptSOCTrigger(ADCC_inst_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN15
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCC_inst_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN15, 500U);
	ADC_setInterruptSOCTrigger(ADCC_inst_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCC_inst_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 500U);
	ADC_setInterruptSOCTrigger(ADCC_inst_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 3 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCC_inst_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN3, 500U);
	ADC_setInterruptSOCTrigger(ADCC_inst_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 4 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCC_inst_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN4, 500U);
	ADC_setInterruptSOCTrigger(ADCC_inst_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 5 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 5
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCC_inst_BASE, ADC_SOC_NUMBER5, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN5, 500U);
	ADC_setInterruptSOCTrigger(ADCC_inst_BASE, ADC_SOC_NUMBER5, ADC_INT_SOC_TRIGGER_NONE);
	//
	// ADC Interrupt 1 Configuration
	// 		Source	: ADC_SOC_NUMBER0
	// 		Interrupt Source: disabled
	// 		Continuous Mode	: disabled
	//
	//
	ADC_setInterruptSource(ADCC_inst_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
	ADC_disableContinuousMode(ADCC_inst_BASE, ADC_INT_NUMBER1);
	ADC_disableInterrupt(ADCC_inst_BASE, ADC_INT_NUMBER1);
}

void ADCD_inst_init(){
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(ADCD_inst_BASE, ADC_CLK_DIV_4_0);
	//
	// Configures the analog-to-digital converter resolution and signal mode.
	//
	ADC_setMode(ADCD_inst_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(ADCD_inst_BASE, ADC_PULSE_END_OF_CONV);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(ADCD_inst_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(ADCD_inst_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(ADCD_inst_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN0
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCD_inst_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN0, 500U);
	ADC_setInterruptSOCTrigger(ADCD_inst_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCD_inst_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN1, 500U);
	ADC_setInterruptSOCTrigger(ADCD_inst_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCD_inst_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 500U);
	ADC_setInterruptSOCTrigger(ADCD_inst_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 3 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCD_inst_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN3, 500U);
	ADC_setInterruptSOCTrigger(ADCD_inst_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 4 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCD_inst_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN4, 500U);
	ADC_setInterruptSOCTrigger(ADCD_inst_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 5 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 5
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 500 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(ADCD_inst_BASE, ADC_SOC_NUMBER5, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN5, 500U);
	ADC_setInterruptSOCTrigger(ADCD_inst_BASE, ADC_SOC_NUMBER5, ADC_INT_SOC_TRIGGER_NONE);
	//
	// ADC Interrupt 1 Configuration
	// 		Source	: ADC_SOC_NUMBER0
	// 		Interrupt Source: disabled
	// 		Continuous Mode	: disabled
	//
	//
	ADC_setInterruptSource(ADCD_inst_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
	ADC_disableContinuousMode(ADCD_inst_BASE, ADC_INT_NUMBER1);
	ADC_disableInterrupt(ADCD_inst_BASE, ADC_INT_NUMBER1);
}



//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
void CPUTIMER_init(){
	CPUTIMER0_inst_init();
	CPUTIMER1_inst_init();
}

void CPUTIMER0_inst_init(){
	CPUTimer_setEmulationMode(CPUTIMER0_inst_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
	CPUTimer_setPreScaler(CPUTIMER0_inst_BASE, 200U);
	CPUTimer_setPeriod(CPUTIMER0_inst_BASE, 50U);
	CPUTimer_enableInterrupt(CPUTIMER0_inst_BASE);
	CPUTimer_stopTimer(CPUTIMER0_inst_BASE);

	CPUTimer_reloadTimerCounter(CPUTIMER0_inst_BASE);
	CPUTimer_startTimer(CPUTIMER0_inst_BASE);
}
void CPUTIMER1_inst_init(){
	CPUTimer_setEmulationMode(CPUTIMER1_inst_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
	CPUTimer_setPreScaler(CPUTIMER1_inst_BASE, 100U);
	CPUTimer_setPeriod(CPUTIMER1_inst_BASE, 65535U);
	CPUTimer_disableInterrupt(CPUTIMER1_inst_BASE);
	CPUTimer_stopTimer(CPUTIMER1_inst_BASE);

	CPUTimer_reloadTimerCounter(CPUTIMER1_inst_BASE);
	CPUTimer_startTimer(CPUTIMER1_inst_BASE);
}

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
void GPIO_init(){
	LED1_GPIO_init();
	LED2_GPIO_init();
	LED3_GPIO_init();
	LED4_GPIO_init();
	inst_GPIO2_init();
	inst_GPIO3_init();
	inst_GPIO4_init();
	inst_GPIO5_init();
	inst_GPIO6_init();
	inst_GPIO7_init();
	inst_GPIO8_init();
	inst_GPIO9_init();
	inst_GPIO11_init();
	inst_GPIO12_init();
	inst_GPIO13_init();
	inst_GPIO14_init();
	inst_GPIO15_init();
	inst_GPIO10_init();
	inst_GPIO20_init();
	inst_GPIO21_init();
	inst_GPIO22_init();
	inst_GPIO23_init();
	inst_GPIO24_init();
	inst_GPIO25_init();
	inst_GPIO26_init();
	inst_GPIO27_init();
	inst_GPIO30_init();
	inst_GPIO32_init();
	inst_GPIO33_init();
	inst_GPIO36_init();
	inst_GPIO43_init();
	inst_GPIO53_init();
	inst_GPIO54_init();
	inst_GPIO55_init();
	inst_GPIO56_init();
	inst_GPIO57_init();
	inst_GPIO62_init();
	inst_GPIO63_init();
	inst_GPIO64_init();
	inst_GPIO65_init();
	inst_GPIO66_init();
	inst_GPIO84_init();
	inst_GPIO93_init();
	inst_GPIO94_init();
	inst_GPIO95_init();
	inst_GPIO96_init();
	inst_GPIO97_init();
	inst_GPIO98_init();
	inst_GPIO99_init();
	inst_GPIO100_init();
	inst_GPIO101_init();
	inst_GPIO102_init();
	inst_GPIO103_init();
	inst_GPIO104_init();
	inst_GPIO105_init();
	inst_GPIO108_init();
	inst_GPIO110_init();
	inst_GPIO111_init();
	inst_GPIO119_init();
	inst_GPIO125_init();
	inst_GPIO126_init();
	inst_GPIO127_init();
	inst_GPIO128_init();
	inst_GPIO129_init();
	inst_GPIO130_init();
	inst_GPIO131_init();
	inst_GPIO132_init();
	inst_GPIO133_init();
	inst_GPIO134_init();
	inst_GPIO135_init();
	inst_GPIO136_init();
	inst_GPIO137_init();
	inst_GPIO138_init();
	inst_GPIO139_init();
	inst_GPIO140_init();
	inst_GPIO141_init();
	inst_GPIO142_init();
	inst_GPIO143_init();
	inst_GPIO144_init();
	inst_GPIO145_init();
	inst_GPIO146_init();
	inst_GPIO147_init();
	inst_GPIO148_init();
	inst_GPIO149_init();
	inst_GPIO150_init();
	inst_GPIO151_init();
	inst_GPIO152_init();
	inst_GPIO153_init();
	inst_GPIO154_init();
	inst_GPIO155_init();
	inst_GPIO156_init();
	inst_GPIO157_init();
	inst_GPIO158_init();
	inst_GPIO159_init();
	inst_GPIO160_init();
	inst_GPIO161_init();
	inst_GPIO162_init();
	inst_GPIO163_init();
	inst_GPIO164_init();
	inst_GPIO165_init();
	inst_GPIO166_init();
	inst_GPIO167_init();
	inst_GPIO168_init();
	inst_GPIO72_init();
}

void LED1_GPIO_init(){
	GPIO_writePin(LED1_GPIO, 0);
	GPIO_setPadConfig(LED1_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED1_GPIO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED1_GPIO, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(LED1_GPIO, GPIO_CORE_CPU1);
}
void LED2_GPIO_init(){
	GPIO_writePin(LED2_GPIO, 0);
	GPIO_setPadConfig(LED2_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED2_GPIO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED2_GPIO, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(LED2_GPIO, GPIO_CORE_CPU1);
}
void LED3_GPIO_init(){
	GPIO_writePin(LED3_GPIO, 0);
	GPIO_setPadConfig(LED3_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED3_GPIO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED3_GPIO, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(LED3_GPIO, GPIO_CORE_CPU1);
}
void LED4_GPIO_init(){
	GPIO_writePin(LED4_GPIO, 0);
	GPIO_setPadConfig(LED4_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED4_GPIO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED4_GPIO, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(LED4_GPIO, GPIO_CORE_CPU1);
}
void inst_GPIO2_init(){
	GPIO_setPadConfig(inst_GPIO2, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO2, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO2, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO2, GPIO_CORE_CPU1);
}
void inst_GPIO3_init(){
	GPIO_setPadConfig(inst_GPIO3, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO3, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO3, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO3, GPIO_CORE_CPU1);
}
void inst_GPIO4_init(){
	GPIO_setPadConfig(inst_GPIO4, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO4, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO4, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO4, GPIO_CORE_CPU1);
}
void inst_GPIO5_init(){
	GPIO_setPadConfig(inst_GPIO5, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO5, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO5, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO5, GPIO_CORE_CPU1);
}
void inst_GPIO6_init(){
	GPIO_setPadConfig(inst_GPIO6, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO6, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO6, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO6, GPIO_CORE_CPU1);
}
void inst_GPIO7_init(){
	GPIO_setPadConfig(inst_GPIO7, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO7, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO7, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO7, GPIO_CORE_CPU1);
}
void inst_GPIO8_init(){
	GPIO_setPadConfig(inst_GPIO8, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO8, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO8, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO8, GPIO_CORE_CPU1);
}
void inst_GPIO9_init(){
	GPIO_setPadConfig(inst_GPIO9, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO9, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO9, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO9, GPIO_CORE_CPU1);
}
void inst_GPIO11_init(){
	GPIO_setPadConfig(inst_GPIO11, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO11, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO11, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO11, GPIO_CORE_CPU1);
}
void inst_GPIO12_init(){
	GPIO_setPadConfig(inst_GPIO12, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO12, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO12, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO12, GPIO_CORE_CPU1);
}
void inst_GPIO13_init(){
	GPIO_setPadConfig(inst_GPIO13, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO13, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO13, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO13, GPIO_CORE_CPU1);
}
void inst_GPIO14_init(){
	GPIO_setPadConfig(inst_GPIO14, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO14, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO14, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO14, GPIO_CORE_CPU1);
}
void inst_GPIO15_init(){
	GPIO_setPadConfig(inst_GPIO15, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO15, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO15, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO15, GPIO_CORE_CPU1);
}
void inst_GPIO10_init(){
	GPIO_setPadConfig(inst_GPIO10, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO10, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO10, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO10, GPIO_CORE_CPU1);
}
void inst_GPIO20_init(){
	GPIO_setPadConfig(inst_GPIO20, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO20, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO20, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO20, GPIO_CORE_CPU1);
}
void inst_GPIO21_init(){
	GPIO_setPadConfig(inst_GPIO21, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO21, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO21, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO21, GPIO_CORE_CPU1);
}
void inst_GPIO22_init(){
	GPIO_setPadConfig(inst_GPIO22, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO22, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO22, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO22, GPIO_CORE_CPU1);
}
void inst_GPIO23_init(){
	GPIO_setPadConfig(inst_GPIO23, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO23, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO23, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO23, GPIO_CORE_CPU1);
}
void inst_GPIO24_init(){
	GPIO_setPadConfig(inst_GPIO24, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO24, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO24, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO24, GPIO_CORE_CPU1);
}
void inst_GPIO25_init(){
	GPIO_setPadConfig(inst_GPIO25, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO25, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO25, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO25, GPIO_CORE_CPU1);
}
void inst_GPIO26_init(){
	GPIO_setPadConfig(inst_GPIO26, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO26, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO26, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO26, GPIO_CORE_CPU1);
}
void inst_GPIO27_init(){
	GPIO_setPadConfig(inst_GPIO27, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO27, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO27, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO27, GPIO_CORE_CPU1);
}
void inst_GPIO30_init(){
	GPIO_setPadConfig(inst_GPIO30, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO30, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO30, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO30, GPIO_CORE_CPU1);
}
void inst_GPIO32_init(){
	GPIO_setPadConfig(inst_GPIO32, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO32, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO32, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO32, GPIO_CORE_CPU1);
}
void inst_GPIO33_init(){
	GPIO_setPadConfig(inst_GPIO33, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO33, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO33, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO33, GPIO_CORE_CPU1);
}
void inst_GPIO36_init(){
	GPIO_setPadConfig(inst_GPIO36, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO36, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO36, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO36, GPIO_CORE_CPU1);
}
void inst_GPIO43_init(){
	GPIO_setPadConfig(inst_GPIO43, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO43, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO43, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO43, GPIO_CORE_CPU1);
}
void inst_GPIO53_init(){
	GPIO_setPadConfig(inst_GPIO53, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO53, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO53, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO53, GPIO_CORE_CPU1);
}
void inst_GPIO54_init(){
	GPIO_setPadConfig(inst_GPIO54, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO54, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO54, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO54, GPIO_CORE_CPU1);
}
void inst_GPIO55_init(){
	GPIO_setPadConfig(inst_GPIO55, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO55, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO55, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO55, GPIO_CORE_CPU1);
}
void inst_GPIO56_init(){
	GPIO_setPadConfig(inst_GPIO56, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO56, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO56, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO56, GPIO_CORE_CPU1);
}
void inst_GPIO57_init(){
	GPIO_setPadConfig(inst_GPIO57, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO57, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO57, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO57, GPIO_CORE_CPU1);
}
void inst_GPIO62_init(){
	GPIO_setPadConfig(inst_GPIO62, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO62, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO62, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO62, GPIO_CORE_CPU1);
}
void inst_GPIO63_init(){
	GPIO_setPadConfig(inst_GPIO63, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO63, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO63, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO63, GPIO_CORE_CPU1);
}
void inst_GPIO64_init(){
	GPIO_setPadConfig(inst_GPIO64, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO64, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO64, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO64, GPIO_CORE_CPU1);
}
void inst_GPIO65_init(){
	GPIO_setPadConfig(inst_GPIO65, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO65, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO65, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO65, GPIO_CORE_CPU1);
}
void inst_GPIO66_init(){
	GPIO_setPadConfig(inst_GPIO66, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO66, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO66, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO66, GPIO_CORE_CPU1);
}
void inst_GPIO84_init(){
	GPIO_setPadConfig(inst_GPIO84, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO84, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO84, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO84, GPIO_CORE_CPU1);
}
void inst_GPIO93_init(){
	GPIO_setPadConfig(inst_GPIO93, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO93, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO93, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO93, GPIO_CORE_CPU1);
}
void inst_GPIO94_init(){
	GPIO_setPadConfig(inst_GPIO94, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO94, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO94, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO94, GPIO_CORE_CPU1);
}
void inst_GPIO95_init(){
	GPIO_setPadConfig(inst_GPIO95, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO95, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO95, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO95, GPIO_CORE_CPU1);
}
void inst_GPIO96_init(){
	GPIO_setPadConfig(inst_GPIO96, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO96, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO96, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO96, GPIO_CORE_CPU1);
}
void inst_GPIO97_init(){
	GPIO_setPadConfig(inst_GPIO97, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO97, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO97, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO97, GPIO_CORE_CPU1);
}
void inst_GPIO98_init(){
	GPIO_setPadConfig(inst_GPIO98, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO98, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO98, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO98, GPIO_CORE_CPU1);
}
void inst_GPIO99_init(){
	GPIO_setPadConfig(inst_GPIO99, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO99, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO99, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO99, GPIO_CORE_CPU1);
}
void inst_GPIO100_init(){
	GPIO_setPadConfig(inst_GPIO100, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO100, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO100, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO100, GPIO_CORE_CPU1);
}
void inst_GPIO101_init(){
	GPIO_setPadConfig(inst_GPIO101, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO101, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO101, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO101, GPIO_CORE_CPU1);
}
void inst_GPIO102_init(){
	GPIO_setPadConfig(inst_GPIO102, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO102, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO102, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO102, GPIO_CORE_CPU1);
}
void inst_GPIO103_init(){
	GPIO_setPadConfig(inst_GPIO103, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO103, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO103, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO103, GPIO_CORE_CPU1);
}
void inst_GPIO104_init(){
	GPIO_setPadConfig(inst_GPIO104, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO104, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO104, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO104, GPIO_CORE_CPU1);
}
void inst_GPIO105_init(){
	GPIO_setPadConfig(inst_GPIO105, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO105, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO105, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO105, GPIO_CORE_CPU1);
}
void inst_GPIO108_init(){
	GPIO_setPadConfig(inst_GPIO108, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO108, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO108, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO108, GPIO_CORE_CPU1);
}
void inst_GPIO110_init(){
	GPIO_setPadConfig(inst_GPIO110, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO110, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO110, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO110, GPIO_CORE_CPU1);
}
void inst_GPIO111_init(){
	GPIO_setPadConfig(inst_GPIO111, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO111, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO111, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO111, GPIO_CORE_CPU1);
}
void inst_GPIO119_init(){
	GPIO_setPadConfig(inst_GPIO119, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO119, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO119, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO119, GPIO_CORE_CPU1);
}
void inst_GPIO125_init(){
	GPIO_setPadConfig(inst_GPIO125, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO125, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO125, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO125, GPIO_CORE_CPU1);
}
void inst_GPIO126_init(){
	GPIO_setPadConfig(inst_GPIO126, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO126, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO126, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO126, GPIO_CORE_CPU1);
}
void inst_GPIO127_init(){
	GPIO_setPadConfig(inst_GPIO127, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO127, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO127, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO127, GPIO_CORE_CPU1);
}
void inst_GPIO128_init(){
	GPIO_setPadConfig(inst_GPIO128, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO128, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO128, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO128, GPIO_CORE_CPU1);
}
void inst_GPIO129_init(){
	GPIO_setPadConfig(inst_GPIO129, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO129, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO129, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO129, GPIO_CORE_CPU1);
}
void inst_GPIO130_init(){
	GPIO_setPadConfig(inst_GPIO130, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO130, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO130, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO130, GPIO_CORE_CPU1);
}
void inst_GPIO131_init(){
	GPIO_setPadConfig(inst_GPIO131, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO131, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO131, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO131, GPIO_CORE_CPU1);
}
void inst_GPIO132_init(){
	GPIO_setPadConfig(inst_GPIO132, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO132, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO132, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO132, GPIO_CORE_CPU1);
}
void inst_GPIO133_init(){
	GPIO_setPadConfig(inst_GPIO133, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO133, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO133, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO133, GPIO_CORE_CPU1);
}
void inst_GPIO134_init(){
	GPIO_setPadConfig(inst_GPIO134, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO134, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO134, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO134, GPIO_CORE_CPU1);
}
void inst_GPIO135_init(){
	GPIO_setPadConfig(inst_GPIO135, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO135, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO135, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO135, GPIO_CORE_CPU1);
}
void inst_GPIO136_init(){
	GPIO_setPadConfig(inst_GPIO136, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO136, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO136, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO136, GPIO_CORE_CPU1);
}
void inst_GPIO137_init(){
	GPIO_setPadConfig(inst_GPIO137, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO137, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO137, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO137, GPIO_CORE_CPU1);
}
void inst_GPIO138_init(){
	GPIO_setPadConfig(inst_GPIO138, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO138, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO138, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO138, GPIO_CORE_CPU1);
}
void inst_GPIO139_init(){
	GPIO_setPadConfig(inst_GPIO139, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO139, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO139, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO139, GPIO_CORE_CPU1);
}
void inst_GPIO140_init(){
	GPIO_setPadConfig(inst_GPIO140, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO140, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO140, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO140, GPIO_CORE_CPU1);
}
void inst_GPIO141_init(){
	GPIO_setPadConfig(inst_GPIO141, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO141, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO141, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO141, GPIO_CORE_CPU1);
}
void inst_GPIO142_init(){
	GPIO_setPadConfig(inst_GPIO142, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO142, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO142, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO142, GPIO_CORE_CPU1);
}
void inst_GPIO143_init(){
	GPIO_setPadConfig(inst_GPIO143, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO143, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO143, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO143, GPIO_CORE_CPU1);
}
void inst_GPIO144_init(){
	GPIO_setPadConfig(inst_GPIO144, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO144, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO144, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO144, GPIO_CORE_CPU1);
}
void inst_GPIO145_init(){
	GPIO_setPadConfig(inst_GPIO145, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO145, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO145, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO145, GPIO_CORE_CPU1);
}
void inst_GPIO146_init(){
	GPIO_setPadConfig(inst_GPIO146, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO146, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO146, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO146, GPIO_CORE_CPU1);
}
void inst_GPIO147_init(){
	GPIO_setPadConfig(inst_GPIO147, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO147, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO147, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO147, GPIO_CORE_CPU1);
}
void inst_GPIO148_init(){
	GPIO_setPadConfig(inst_GPIO148, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO148, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO148, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO148, GPIO_CORE_CPU1);
}
void inst_GPIO149_init(){
	GPIO_setPadConfig(inst_GPIO149, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO149, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO149, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO149, GPIO_CORE_CPU1);
}
void inst_GPIO150_init(){
	GPIO_setPadConfig(inst_GPIO150, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO150, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO150, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO150, GPIO_CORE_CPU1);
}
void inst_GPIO151_init(){
	GPIO_setPadConfig(inst_GPIO151, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO151, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO151, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO151, GPIO_CORE_CPU1);
}
void inst_GPIO152_init(){
	GPIO_setPadConfig(inst_GPIO152, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO152, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO152, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO152, GPIO_CORE_CPU1);
}
void inst_GPIO153_init(){
	GPIO_setPadConfig(inst_GPIO153, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO153, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO153, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO153, GPIO_CORE_CPU1);
}
void inst_GPIO154_init(){
	GPIO_setPadConfig(inst_GPIO154, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO154, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO154, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO154, GPIO_CORE_CPU1);
}
void inst_GPIO155_init(){
	GPIO_setPadConfig(inst_GPIO155, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO155, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO155, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO155, GPIO_CORE_CPU1);
}
void inst_GPIO156_init(){
	GPIO_setPadConfig(inst_GPIO156, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO156, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO156, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO156, GPIO_CORE_CPU1);
}
void inst_GPIO157_init(){
	GPIO_setPadConfig(inst_GPIO157, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO157, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO157, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO157, GPIO_CORE_CPU1);
}
void inst_GPIO158_init(){
	GPIO_setPadConfig(inst_GPIO158, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO158, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO158, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO158, GPIO_CORE_CPU1);
}
void inst_GPIO159_init(){
	GPIO_setPadConfig(inst_GPIO159, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO159, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO159, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO159, GPIO_CORE_CPU1);
}
void inst_GPIO160_init(){
	GPIO_setPadConfig(inst_GPIO160, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO160, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO160, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO160, GPIO_CORE_CPU1);
}
void inst_GPIO161_init(){
	GPIO_setPadConfig(inst_GPIO161, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO161, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO161, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO161, GPIO_CORE_CPU1);
}
void inst_GPIO162_init(){
	GPIO_setPadConfig(inst_GPIO162, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO162, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO162, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO162, GPIO_CORE_CPU1);
}
void inst_GPIO163_init(){
	GPIO_setPadConfig(inst_GPIO163, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO163, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO163, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO163, GPIO_CORE_CPU1);
}
void inst_GPIO164_init(){
	GPIO_setPadConfig(inst_GPIO164, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO164, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO164, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO164, GPIO_CORE_CPU1);
}
void inst_GPIO165_init(){
	GPIO_setPadConfig(inst_GPIO165, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO165, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO165, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO165, GPIO_CORE_CPU1);
}
void inst_GPIO166_init(){
	GPIO_setPadConfig(inst_GPIO166, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO166, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO166, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO166, GPIO_CORE_CPU1);
}
void inst_GPIO167_init(){
	GPIO_setPadConfig(inst_GPIO167, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO167, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO167, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO167, GPIO_CORE_CPU1);
}
void inst_GPIO168_init(){
	GPIO_setPadConfig(inst_GPIO168, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO168, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO168, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO168, GPIO_CORE_CPU1);
}
void inst_GPIO72_init(){
	GPIO_setPadConfig(inst_GPIO72, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(inst_GPIO72, GPIO_QUAL_3SAMPLE);
	GPIO_setDirectionMode(inst_GPIO72, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(inst_GPIO72, GPIO_CORE_CPU1);
}

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************
void INTERRUPT_init(){
	
	// Interrupt Settings for INT_CPUTIMER0_inst
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_CPUTIMER0_inst, &INT_CPUTIMER0_inst_ISR);
	Interrupt_enable(INT_CPUTIMER0_inst);
	
	// Interrupt Settings for INT_SCIA_inst_RX
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_SCIA_inst_RX, &INT_SCIA_inst_RX_ISR);
	Interrupt_enable(INT_SCIA_inst_RX);
	
	// Interrupt Settings for INT_SCIA_inst_TX
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_SCIA_inst_TX, &INT_SCIA_inst_TX_ISR);
	Interrupt_enable(INT_SCIA_inst_TX);
}
//*****************************************************************************
//
// SCI Configurations
//
//*****************************************************************************
void SCI_init(){
	SCIA_inst_init();
}

void SCIA_inst_init(){
	SCI_clearInterruptStatus(SCIA_inst_BASE, SCI_INT_RXFF | SCI_INT_TXFF | SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT | SCI_INT_TXRDY);
	SCI_clearOverflowStatus(SCIA_inst_BASE);
	SCI_resetTxFIFO(SCIA_inst_BASE);
	SCI_resetRxFIFO(SCIA_inst_BASE);
	SCI_resetChannels(SCIA_inst_BASE);
	SCI_setConfig(SCIA_inst_BASE, DEVICE_LSPCLK_FREQ, SCIA_inst_BAUDRATE, (SCI_CONFIG_WLEN_8|SCI_CONFIG_STOP_ONE|SCI_CONFIG_PAR_EVEN));
	SCI_disableLoopback(SCIA_inst_BASE);
	SCI_performSoftwareReset(SCIA_inst_BASE);
	SCI_enableInterrupt(SCIA_inst_BASE, SCI_INT_RXFF | SCI_INT_TXFF);
	SCI_setFIFOInterruptLevel(SCIA_inst_BASE, SCI_FIFO_TX0, SCI_FIFO_RX1);
	SCI_enableInterrupt(SCIA_inst_BASE, SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR);
	SCI_enableFIFO(SCIA_inst_BASE);
	SCI_enableModule(SCIA_inst_BASE);
}

//
// SYSCTL_init is generated in a separate file.
//

