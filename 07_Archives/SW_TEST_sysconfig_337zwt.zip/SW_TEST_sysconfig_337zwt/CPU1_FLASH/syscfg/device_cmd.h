#ifndef DEVICE_CMD_H
#define DEVICE_CMD_H

#include <cpy_tbl.h>


#ifdef CMD0_ins
void CMD0_ins_init();
#endif

void CMD_init();

#endif
