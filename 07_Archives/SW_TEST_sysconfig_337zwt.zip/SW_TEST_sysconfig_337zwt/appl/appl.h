/*
 * appl.h
 *
 *  Created on: 1 Sep 2025
 *      Author: Deyan Todorov
 */

#ifndef APPL_APPL_H_
#define APPL_APPL_H_

void APPL_preinit(void);
void APPL_postinit(void);
void APPL_main(void);

#endif /* APPL_APPL_H_ */
